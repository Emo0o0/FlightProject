class City:
    pass
