class Country:
    pass
